#!/bin/bash
#	$Id$
#
gmt psxy -R0/3/0/0.1 -Jx1i -P -U"optional command string or text here" -T > GMT_-U.ps
