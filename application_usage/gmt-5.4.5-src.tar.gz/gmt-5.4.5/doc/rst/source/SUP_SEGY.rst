####
SEGY
####

.. toctree::
   :maxdepth: 1

   supplements/segy/pssegy
   supplements/segy/pssegyz
   supplements/segy/segy2grd
