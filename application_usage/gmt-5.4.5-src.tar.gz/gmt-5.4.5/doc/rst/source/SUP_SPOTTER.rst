#######
SPOTTER
#######

.. toctree::
   :maxdepth: 1

   supplements/spotter/backtracker
   supplements/spotter/gmtpmodeler
   supplements/spotter/grdpmodeler
   supplements/spotter/grdrotater
   supplements/spotter/grdspotter
   supplements/spotter/hotspotter
   supplements/spotter/originator
   supplements/spotter/rotconverter
   supplements/spotter/rotsmoother
