#
F
#

.. toctree::
   :maxdepth: 1

   filter1d
   fitcircle
