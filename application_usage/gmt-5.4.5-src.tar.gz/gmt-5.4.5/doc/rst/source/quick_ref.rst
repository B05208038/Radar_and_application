##############
Module Purpose
##############

.. include:: quick_ref.rst_
