#
B
#

.. toctree::
   :maxdepth: 1

   blockmean
   blockmedian
   blockmode
