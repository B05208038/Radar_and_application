#
T
#

.. toctree::
   :maxdepth: 1

   trend1d
   trend2d
   triangulate
