#########
POTENTIAL
#########

.. toctree::
   :maxdepth: 1

   supplements/potential/gmtgravmag3d
   supplements/potential/gmtflexure
   supplements/potential/gpsgridder
   supplements/potential/gravfft
   supplements/potential/grdflexure
   supplements/potential/grdgravmag3d
   supplements/potential/grdredpol
   supplements/potential/grdseamount
   supplements/potential/talwani2d
   supplements/potential/talwani3d
