.. _longfinnedpilotwhale:

A Long-finned Pilot Whale
-------------------------

.. literalinclude:: longfinnedpilotwhale.def
