.. _unidentifiedwhale_high:

An Unidentified Whale (high)
----------------------------

.. literalinclude:: unidentifiedwhale_high.def
