.. _geo-cleavage_vert:

Strike of vertical cleavage
---------------------------

.. literalinclude:: geo-cleavage_vert.def
