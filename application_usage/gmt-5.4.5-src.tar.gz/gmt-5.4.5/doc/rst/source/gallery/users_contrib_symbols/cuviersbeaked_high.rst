.. _cuviersbeaked_high:

A Cuvier's Beaked Whale (high)
------------------------------

.. literalinclude:: cuviersbeaked_high.def
