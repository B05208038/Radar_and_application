.. _geo-joint:

Strike, dip direction and dip of joints
---------------------------------------

.. literalinclude:: geo-joint.def
