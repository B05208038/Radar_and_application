.. _beluga:

A Beluga whale
--------------

.. literalinclude:: beluga.def
