.. _southernrightwhale_low:

A Southern Right Whale (low)
----------------------------

.. literalinclude:: southernrightwhale_low.def
