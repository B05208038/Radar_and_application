.. _killerwhale_low:

A Killer Whale (low)
--------------------

.. literalinclude:: killerwhale_low.def
