.. _beluga_low:

A Beluga whale (low)
--------------------

.. literalinclude:: beluga_low.def
