.. _killerwhale_high:

A Killer Whale (high)
---------------------

.. literalinclude:: killerwhale_high.def
