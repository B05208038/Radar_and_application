.. _humpbacktail_two_low:

Two Humpback Whale Tails (low)
------------------------------

.. literalinclude:: humpbacktail_two_low.def
