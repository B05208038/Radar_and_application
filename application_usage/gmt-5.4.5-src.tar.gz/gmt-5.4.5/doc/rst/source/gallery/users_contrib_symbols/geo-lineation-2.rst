.. _geo-lineation-2:

Trend and plunge of lineation 2
-------------------------------

.. literalinclude:: geo-lineation-2.def
