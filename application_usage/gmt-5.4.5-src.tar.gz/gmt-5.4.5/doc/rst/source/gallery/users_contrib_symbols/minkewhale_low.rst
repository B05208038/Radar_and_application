.. _minkewhale_low:

A Minke Whale (low)
-------------------

.. literalinclude:: minkewhale_low.def
