.. _spermwhale_high:

A Sperm Whale (high)
--------------------

.. literalinclude:: spermwhale_high.def
