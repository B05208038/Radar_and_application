.. _atlantwhitesided_low:

An Atlantic White-sided Whale (low)
------------------------------------

.. literalinclude:: atlantwhitesided_low.def
