.. _stripeddolphin_low:

A Striped Dolphin (low)
-----------------------

.. literalinclude:: stripeddolphin_low.def
