.. _geo-cleavage_hor:

Horizontal cleavage
-------------------

.. literalinclude:: geo-cleavage_hor.def
