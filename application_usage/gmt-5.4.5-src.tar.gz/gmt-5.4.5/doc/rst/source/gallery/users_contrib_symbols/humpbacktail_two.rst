.. _humpbacktail_two:

Two Humpback Whale Tails
------------------------

.. literalinclude:: humpbacktail_two.def
