.. _geo-plane_vert:

Strike of vertical beds
-----------------------

.. literalinclude:: geo-plane_vert.def
