.. _beluga_high:

A Beluga whale (high)
---------------------

.. literalinclude:: beluga_high.def
