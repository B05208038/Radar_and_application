.. _longfinnedpilotwhale_high:

A Long-finned Pilot Whale (high)
--------------------------------

.. literalinclude:: longfinnedpilotwhale_high.def
