.. _geo-lineation:

Trend and plunge of lineation
-----------------------------

.. literalinclude:: geo-lineation.def
