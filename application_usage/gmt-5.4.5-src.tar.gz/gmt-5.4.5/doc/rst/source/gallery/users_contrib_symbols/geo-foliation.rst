.. _geo-foliation:

Strike, dip direction and dip of foliation
------------------------------------------

.. literalinclude:: geo-foliation.def
