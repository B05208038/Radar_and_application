.. _geo-plane_hor:

Horizontal beds
---------------

.. literalinclude:: geo-plane_hor.def
