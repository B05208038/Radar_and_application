.. _minkewhale_high:

A Minke Whale (high)
--------------------

.. literalinclude:: minkewhale_high.def
