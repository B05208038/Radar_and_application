.. _geo-lineation_hor:

Horizontal lineation
--------------------

.. literalinclude:: geo-lineation_hor.def
