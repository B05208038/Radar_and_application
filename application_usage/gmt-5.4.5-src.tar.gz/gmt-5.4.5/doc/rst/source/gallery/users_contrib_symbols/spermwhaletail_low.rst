.. _spermwhaletail_low:

A Sperm Whale Tail (low)
------------------------

.. literalinclude:: spermwhaletail_low.def
