.. _geo-cleavage:

Strike, dip direction and dip of cleavage
-----------------------------------------

.. literalinclude:: geo-cleavage.def
