.. _stripeddolphin_high:

A Striped Dolphin (high)
------------------------

.. literalinclude:: stripeddolphin_high.def
