.. _pirata:

A pirate
----------

.. literalinclude:: pirata.def
