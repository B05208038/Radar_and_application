.. _longfinnedpilotwhale_low:

A Long-finned Pilot Whale (low)
-------------------------------

.. literalinclude:: longfinnedpilotwhale_low.def
