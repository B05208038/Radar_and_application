.. _cuviersbeaked_low:

A Cuvier's Beaked Whale (low)
-----------------------------

.. literalinclude:: cuviersbeaked_low.def
