.. _geo-plane_steep:

Strike and dip direction of steeply dipping beds
------------------------------------------------

.. literalinclude:: geo-plane_steep.def
