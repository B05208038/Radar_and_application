.. _spermwhaletail:

A Sperm Whale Tail
------------------

.. literalinclude:: spermwhaletail.def
