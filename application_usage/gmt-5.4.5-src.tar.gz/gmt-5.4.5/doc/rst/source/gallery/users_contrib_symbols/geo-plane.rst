.. _geo-plane:

Strike, dip direction and dip of beds
-------------------------------------

.. literalinclude:: geo-plane.def
