.. _geo-lineation-3:

Trend and plunge of lineation 3
-------------------------------

.. literalinclude:: geo-lineation-3.def
