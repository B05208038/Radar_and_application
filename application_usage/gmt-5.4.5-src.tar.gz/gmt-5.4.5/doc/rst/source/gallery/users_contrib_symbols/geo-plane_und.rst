.. _geo-plane_und:

Strike, dip direction and dip of crenulated or undulated beds
-------------------------------------------------------------

.. literalinclude:: geo-plane_und.def
