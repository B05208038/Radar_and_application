.. _geo-plane_gentle:

Strike and dip direction of gently dipping beds
-----------------------------------------------

.. literalinclude:: geo-plane_gentle.def
