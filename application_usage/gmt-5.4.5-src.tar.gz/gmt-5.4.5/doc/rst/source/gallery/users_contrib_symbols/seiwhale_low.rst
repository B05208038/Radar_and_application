.. _seiwhale_low:

A Sei Whale (low)
-----------------

.. literalinclude:: seiwhale_low.def
