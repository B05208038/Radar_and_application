.. _humpbacktail_one_low:

One Humpback Whale Tail (low)
-----------------------------

.. literalinclude:: humpbacktail_one_low.def
