.. _geo-plane_rake:

Strike, dip direction and dip of bed with rake of lineation
-----------------------------------------------------------

.. literalinclude:: geo-plane_rake.def
