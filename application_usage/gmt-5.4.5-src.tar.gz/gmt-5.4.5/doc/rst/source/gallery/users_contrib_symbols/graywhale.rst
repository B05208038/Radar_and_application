.. _graywhale:

A Gray Whale
------------

.. literalinclude:: graywhale.def
