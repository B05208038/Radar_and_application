.. _northernrightwhale_low:

A Northern Right Whale (low)
----------------------------

.. literalinclude:: northernrightwhale_low.def
