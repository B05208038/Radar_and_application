.. _unidentifiedbeakedwhale_high:

An Unidentified Beaked Whale (high)
-----------------------------------

.. literalinclude:: unidentifiedbeakedwhale_high.def
