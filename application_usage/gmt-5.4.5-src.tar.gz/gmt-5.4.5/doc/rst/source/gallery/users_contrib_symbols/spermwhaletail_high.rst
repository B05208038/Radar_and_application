.. _spermwhaletail_high:

A Sperm Whale Tail (high)
-------------------------

.. literalinclude:: spermwhaletail_high.def
