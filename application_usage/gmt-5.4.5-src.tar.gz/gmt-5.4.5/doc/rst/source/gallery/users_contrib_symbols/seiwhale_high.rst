.. _seiwhale_high:

A Sei Whale (high)
------------------

.. literalinclude:: seiwhale_high.def
