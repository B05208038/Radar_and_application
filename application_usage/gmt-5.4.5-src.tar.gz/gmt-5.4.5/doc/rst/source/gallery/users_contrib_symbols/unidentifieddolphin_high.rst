.. _unidentifieddolphin_high:

An Unidentified Dolphin (high)
------------------------------

.. literalinclude:: unidentifieddolphin_high.def
