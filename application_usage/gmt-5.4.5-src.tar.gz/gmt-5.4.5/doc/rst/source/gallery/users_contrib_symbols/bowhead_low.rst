.. _bowhead_low:

A Bowhead Whale (low)
---------------------

.. literalinclude:: bowhead_low.def
