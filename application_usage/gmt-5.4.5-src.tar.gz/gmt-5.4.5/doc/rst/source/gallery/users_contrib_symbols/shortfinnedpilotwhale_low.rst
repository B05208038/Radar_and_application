.. _shortfinnedpilotwhale_low:

A Short-finned Pilot Whale (low)
--------------------------------

.. literalinclude:: shortfinnedpilotwhale_low.def
