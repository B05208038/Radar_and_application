.. _spermwhale_low:

A Sperm Whale (low)
-------------------

.. literalinclude:: spermwhale_low.def
