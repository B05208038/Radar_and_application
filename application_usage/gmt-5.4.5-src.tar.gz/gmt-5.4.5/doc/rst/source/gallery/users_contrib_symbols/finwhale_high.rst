.. _finwhale_high:

A Fin Whale (high)
------------------

.. literalinclude:: finwhale_high.def
