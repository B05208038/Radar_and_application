.. _stripeddolphin:

A Striped Dolphin
-----------------

.. literalinclude:: stripeddolphin.def
