.. _bottlenose_high:

A Bottlenose Dolphin (high)
---------------------------

.. literalinclude:: bottlenose_high.def
