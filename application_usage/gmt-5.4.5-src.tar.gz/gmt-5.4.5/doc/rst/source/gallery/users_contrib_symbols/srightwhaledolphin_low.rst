.. _srightwhaledolphin_low:

A Southern Right Whale Dolphin (low)
------------------------------------

.. literalinclude:: srightwhaledolphin_low.def
