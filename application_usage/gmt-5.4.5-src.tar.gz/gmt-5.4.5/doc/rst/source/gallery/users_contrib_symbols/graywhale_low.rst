.. _graywhale_low:

A Gray Whale (low)
------------------

.. literalinclude:: graywhale_low.def
