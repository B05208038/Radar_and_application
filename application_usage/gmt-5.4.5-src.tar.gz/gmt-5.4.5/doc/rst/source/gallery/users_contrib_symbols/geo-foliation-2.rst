.. _geo-foliation-2:

Strike, dip direction and dip of foliation 2
--------------------------------------------

.. literalinclude:: geo-foliation-2.def
