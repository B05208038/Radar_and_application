.. _graywhale_high:

A Gray Whale (high)
-------------------

.. literalinclude:: graywhale_high.def
