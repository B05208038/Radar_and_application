.. _rissosdolphin_high:

A Risso's Dolphin (high)
------------------------

.. literalinclude:: rissosdolphin_high.def
