.. _commondolphin_midhigh:

A Common Dolphin (mid-high)
---------------------------

.. literalinclude:: commondolphin_midhigh.def
