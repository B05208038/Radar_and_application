.. _unidentifiedbeakedwhale_low:

An Unidentified Beaked Whale (low)
----------------------------------

.. literalinclude:: unidentifiedbeakedwhale_low.def
