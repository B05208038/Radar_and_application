.. _srightwhaledolphin_high:

A Southern Right Whale Dolphin (high)
-------------------------------------

.. literalinclude:: srightwhaledolphin_high.def
