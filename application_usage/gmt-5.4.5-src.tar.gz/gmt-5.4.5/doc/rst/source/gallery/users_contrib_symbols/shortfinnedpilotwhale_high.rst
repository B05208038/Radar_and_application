.. _shortfinnedpilotwhale_high:

A Short-finned Pilot Whale (high)
---------------------------------

.. literalinclude:: shortfinnedpilotwhale_high.def
