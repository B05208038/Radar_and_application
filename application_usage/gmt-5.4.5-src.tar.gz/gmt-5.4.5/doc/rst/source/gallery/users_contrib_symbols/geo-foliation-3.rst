.. _geo-foliation-3:

Strike, dip direction and dip of foliation 3
--------------------------------------------

.. literalinclude:: geo-foliation-3.def
