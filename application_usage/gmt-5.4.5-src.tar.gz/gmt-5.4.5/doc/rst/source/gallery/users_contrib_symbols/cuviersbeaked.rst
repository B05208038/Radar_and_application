.. _cuviersbeaked:

A Cuvier's Beaked Whale
-----------------------

.. literalinclude:: cuviersbeaked.def
