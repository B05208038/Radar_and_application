.. _geo-plane_medium:

Strike and dip direction of moderately dipping beds
---------------------------------------------------

.. literalinclude:: geo-plane_medium.def
