.. _southernrightwhale:

A Southern Right Whale
----------------------

.. literalinclude:: southernrightwhale.def
