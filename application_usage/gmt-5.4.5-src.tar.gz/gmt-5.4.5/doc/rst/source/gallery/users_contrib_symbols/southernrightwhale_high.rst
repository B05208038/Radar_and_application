.. _southernrightwhale_high:

A Southern Right Whale (high)
-----------------------------

.. literalinclude:: southernrightwhale_high.def
