.. _geo-foliation_hor:

Horizontal foliation
--------------------

.. literalinclude:: geo-foliation_hor.def
