.. _atlantwhitesided_high:

An Atlantic White-sided Whale (high)
------------------------------------

.. literalinclude:: atlantwhitesided_high.def
