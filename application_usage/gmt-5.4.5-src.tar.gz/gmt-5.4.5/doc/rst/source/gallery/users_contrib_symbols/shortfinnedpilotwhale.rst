.. _shortfinnedpilotwhale:

A Short-finned Pilot Whale
--------------------------

.. literalinclude:: shortfinnedpilotwhale.def
