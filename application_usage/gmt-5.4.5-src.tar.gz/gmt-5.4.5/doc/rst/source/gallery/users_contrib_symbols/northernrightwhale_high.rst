.. _northernrightwhale_high:

A Northern Right Whale (high)
-----------------------------

.. literalinclude:: northernrightwhale_high.def
