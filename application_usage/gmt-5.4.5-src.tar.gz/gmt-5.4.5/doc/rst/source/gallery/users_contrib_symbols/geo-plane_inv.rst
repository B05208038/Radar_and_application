.. _geo-plane_inv:

Strike, dip direction and dip of overturned beds
------------------------------------------------

.. literalinclude:: geo-plane_inv.def
