.. _rissosdolphin_low:

A Risso's Dolphin (low)
-----------------------

.. literalinclude:: rissosdolphin_low.def
