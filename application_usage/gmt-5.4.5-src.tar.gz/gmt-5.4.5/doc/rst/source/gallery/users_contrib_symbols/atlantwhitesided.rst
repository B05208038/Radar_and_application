.. _atlantwhitesided:

An Atlantic White-sided Whale
-----------------------------

.. literalinclude:: atlantwhitesided.def
