.. _commondolphin_midlow:

A Common Dolphin (mid-low)
--------------------------

.. literalinclude:: commondolphin_midlow.def
