.. _geo-lineation_vert:

Vertical lineation
------------------

.. literalinclude:: geo-lineation_vert.def
