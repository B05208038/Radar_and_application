.. _geo-joint_hor:

Horizontal joints
-----------------

.. literalinclude:: geo-joint_hor.def
