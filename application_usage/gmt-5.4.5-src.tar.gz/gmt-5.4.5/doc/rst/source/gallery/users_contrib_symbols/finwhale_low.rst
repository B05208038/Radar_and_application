.. _finwhale_low:

A Fin Whale (low)
-----------------

.. literalinclude:: finwhale_low.def
