.. _geo-joint_vert:

Strike of vertical joints
-------------------------

.. literalinclude:: geo-joint_vert.def
