.. _bowhead_high:

A Bowhead Whale (high)
----------------------

.. literalinclude:: bowhead_high.def
