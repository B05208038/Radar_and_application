.. _geo-foliation_vert:

Strike of vertical foliation
----------------------------

.. literalinclude:: geo-foliation_vert.def
