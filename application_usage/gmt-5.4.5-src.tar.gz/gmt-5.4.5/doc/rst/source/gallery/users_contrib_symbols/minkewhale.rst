.. _minkewhale:

A Minke Whale
-------------

.. literalinclude:: minkewhale.def
