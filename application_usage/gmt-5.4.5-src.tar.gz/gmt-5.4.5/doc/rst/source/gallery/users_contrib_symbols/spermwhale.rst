.. _spermwhale:

A Sperm Whale
-------------

.. literalinclude:: spermwhale.def
