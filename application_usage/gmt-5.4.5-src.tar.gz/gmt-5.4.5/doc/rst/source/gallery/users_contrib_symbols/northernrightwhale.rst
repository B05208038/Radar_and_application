.. _northernrightwhale:

A Northern Right Whale
----------------------

.. literalinclude:: northernrightwhale.def
