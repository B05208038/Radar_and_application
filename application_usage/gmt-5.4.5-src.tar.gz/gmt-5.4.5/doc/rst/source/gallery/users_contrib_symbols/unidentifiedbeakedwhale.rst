.. _unidentifiedbeakedwhale:

An Unidentified Beaked Whale
----------------------------

.. literalinclude:: unidentifiedbeakedwhale.def
